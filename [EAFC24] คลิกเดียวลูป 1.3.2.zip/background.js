chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.type == "USER_ID") {
        let userId = request.name;
        chrome.storage.sync.set({ 'userId': userId }, function () {
        });
    }
});

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.type == "GET_USER_ID") {
        chrome.storage.sync.get('userId', function (data) {
            sendResponse({ userId: data.userId });
        });
        return true;
    }
});