(function () {
    const MAX_ATTEMPTS = 100;
    const INTERVAL = 50; // 100ms
    let attempts = 0;

    function scanAndClick() {
        const span = Array.from(document.querySelectorAll("button"))
            .find(el => el.textContent.trim() === "Confirm and pay" && el.getAttribute("aria-disabled") !== "true");

        if (span) {
            console.log("Found 'Confirm and pay' button. Attempting to click...");
            span.click();

            clearInterval(intervalId); // Stop scanning once the button is clicked
        }

        console.log(`Attempt ${attempt}: Found span: ${span}`);

        attempts++;
        if (attempts >= MAX_ATTEMPTS) {
            console.log("Max attempts reached. Stopping the scan.");
            clearInterval(intervalId);
        }
    }

    const intervalId = setInterval(scanAndClick, INTERVAL);
})();
